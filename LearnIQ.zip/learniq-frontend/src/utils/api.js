import axios from 'axios'
import { getToken, logout } from './auth'

const api = axios.create({
  baseURL: (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080') + '/api/v1',
})

// Attach token to every request
api.interceptors.request.use((config) => {
  const token = getToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
}, (error) => {
  return Promise.reject(error)
})

// Handle token expiration/invalidity - Hardened to prevent 'random redirects'
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Only logout if it is a genuine 401 and not a public route
    const isPublic = error.config?.url?.includes('/auth/') && !error.config?.url?.includes('/me');
    if (error.response?.status === 401 && !isPublic) {
      console.warn('Session expired or unauthorized. Logging out.')
      // Prevent recursive redirects or logout on already cleared sessions
      if (getToken()) {
        logout()
      }
    }
    return Promise.reject(error)
  }
)

export default api
