package learniq_backend.controller;

import learniq_backend.dto.TestAttemptResponse;
import learniq_backend.service.AttemptService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/v1/attempts")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class TestAttemptController {

    private final AttemptService attemptService;

    @GetMapping("/me")
    public ResponseEntity<List<TestAttemptResponse>> getMyAttempts(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.ok(Collections.emptyList());
        }

        String userEmail = authentication.getName();
        return ResponseEntity.ok(attemptService.getUserAttempts(userEmail));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TestAttemptResponse> getAttemptById(@PathVariable Long id, Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        String userEmail = authentication.getName();
        return ResponseEntity.ok(attemptService.getUserAttempts(userEmail).stream()
                .filter(a -> a.getId().equals(id))
                .findFirst()
                .orElse(null));
    }
}
