package learniq_backend.service;

import learniq_backend.model.*;
import learniq_backend.repository.*;
import learniq_backend.dto.TestAttemptResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AttemptService {

    private final TestAttemptRepository testAttemptRepository;
    private final TestRepository testRepository;
    private final UserRepository userRepository;
    private final QuestionRepository questionRepository;
    private final AttemptAnswerRepository attemptAnswerRepository;

    @Transactional
    public TestAttempt startOrResumeAttempt(String userEmail, Long testId) {
        Test test = testRepository.findById(testId)
                .orElseThrow(() -> new RuntimeException("Test not found"));

        // 1. Check for an existing IN_PROGRESS attempt
        Optional<TestAttempt> existingOpt = testAttemptRepository
                .findFirstByUserEmailAndTestIdAndStatusOrderByStartedAtDesc(userEmail, testId, TestAttempt.Status.IN_PROGRESS);

        if (existingOpt.isPresent()) {
            TestAttempt existing = existingOpt.get();
            // 2. Auto-expiry check
            if (LocalDateTime.now().isAfter(existing.getEndTime())) {
                existing.setStatus(TestAttempt.Status.EXPIRED);
                testAttemptRepository.save(existing);
            } else {
                return existing; // Resume active attempt
            }
        }

        // 3. Prevent multiple attempts for MAIN tests if already submitted
        if ("MAIN".equalsIgnoreCase(test.getSectionType())) {
            Optional<TestAttempt> submitted = testAttemptRepository
                    .findFirstByUserEmailAndTestIdAndStatusOrderByStartedAtDesc(userEmail, testId, TestAttempt.Status.SUBMITTED);
            if (submitted.isPresent()) {
                throw new RuntimeException("You have already submitted this assessment.");
            }
        }

        // 4. Create new attempt
        String userName = userRepository.findByEmail(userEmail).map(User::getName).orElse("Student");
        LocalDateTime now = LocalDateTime.now();
        
        TestAttempt newAttempt = TestAttempt.builder()
                .userEmail(userEmail)
                .userName(userName)
                .test(test)
                .startedAt(now)
                .endTime(now.plusMinutes(test.getDurationMinutes()))
                .status(TestAttempt.Status.IN_PROGRESS)
                .scorePercent(-1) // Placeholder for in-progress
                .build();

        return testAttemptRepository.save(newAttempt);
    }

    public long getRemainingSeconds(Long attemptId) {
        TestAttempt attempt = testAttemptRepository.findById(attemptId)
                .orElseThrow(() -> new RuntimeException("Attempt not found"));

        if (attempt.getStatus() != TestAttempt.Status.IN_PROGRESS) {
            return 0;
        }

        long remaining = Duration.between(LocalDateTime.now(), attempt.getEndTime()).getSeconds();
        return Math.max(0, remaining);
    }

    @Transactional
    public TestAttempt submitAttempt(Long attemptId, Map<String, String> answers) {
        TestAttempt attempt = testAttemptRepository.findById(attemptId)
                .orElseThrow(() -> new RuntimeException("Attempt not found"));

        if (attempt.getStatus() != TestAttempt.Status.IN_PROGRESS) {
            throw new RuntimeException("This attempt is no longer active (Status: " + attempt.getStatus() + ")");
        }

        // Enforce time limit (with 1 min grace)
        if (LocalDateTime.now().isAfter(attempt.getEndTime().plusMinutes(1))) {
            attempt.setStatus(TestAttempt.Status.EXPIRED);
            testAttemptRepository.save(attempt);
            throw new RuntimeException("Submission rejected: Time limit exceeded.");
        }

        // Grade the attempt
        List<Question> questions = questionRepository.findByTestId(attempt.getTest().getId());
        int correctCount = 0;
        List<AttemptAnswer> attemptAnswers = new ArrayList<>();

        for (Question q : questions) {
            String selected = answers != null ? answers.get(String.valueOf(q.getId())) : null;
            boolean isCorrect = q.getCorrectAnswer() != null && q.getCorrectAnswer().equalsIgnoreCase(selected == null ? "" : selected.trim());
            
            if (isCorrect) correctCount++;

            attemptAnswers.add(AttemptAnswer.builder()
                    .attempt(attempt)
                    .questionId(q.getId())
                    .selectedOption(selected)
                    .isCorrect(isCorrect)
                    .build());
        }

        int total = questions.size();
        int scorePercent = total == 0 ? 0 : (correctCount * 100) / total;

        attempt.setTotalQuestions(total);
        attempt.setCorrectCount(correctCount);
        attempt.setWrongCount(total - correctCount);
        attempt.setScorePercent(scorePercent);
        attempt.setStatus(TestAttempt.Status.SUBMITTED);
        attempt.setSubmittedAt(LocalDateTime.now());
        attempt.setAnswers(attemptAnswers);

        return testAttemptRepository.save(attempt);
    }

    public List<TestAttemptResponse> getUserAttempts(String email) {
        if (email == null || email.isBlank()) {
            return Collections.emptyList();
        }

        List<TestAttempt> attempts = testAttemptRepository.findByUserEmailOrderBySubmittedAtDesc(email);
        
        if (attempts == null || attempts.isEmpty()) {
            return Collections.emptyList();
        }

        return attempts.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private TestAttemptResponse mapToResponse(TestAttempt attempt) {
        if (attempt == null) return null;

        Long testId = null;
        String testTitle = "Unknown Test";
        String category = "Unknown";

        if (attempt.getTest() != null) {
            testId = attempt.getTest().getId();
            testTitle = attempt.getTest().getTitle();
            category = attempt.getTest().getCategory();
        }

        return TestAttemptResponse.builder()
                .id(attempt.getId())
                .testId(testId)
                .testTitle(testTitle)
                .category(category)
                .scorePercent(attempt.getScorePercent())
                .correctCount(attempt.getCorrectCount())
                .wrongCount(attempt.getWrongCount())
                .submittedAt(attempt.getSubmittedAt())
                .status(attempt.getStatus() != null ? attempt.getStatus().name() : null)
                .build();
    }
}
