package learniq_backend.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "attempt_answers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttemptAnswer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "attempt_id")
    private TestAttempt attempt;

    @Column(nullable = false)
    private Long questionId;

    @Column
    private String selectedOption;

    @Column
    private boolean isCorrect;
}
